一、免责声明：
Demo 仅供参考，实际开发中需要结合具体业务场景修改使用。

二、Demo运行环境
1）Android：支持 Android 2.3 及以上的系统版本运行
2）iOS：iOS 6.0 以上(包含 iOS 6.0)

三、文档资源
请参考支付宝文档中心的 App 支付 SDK 文档(https://opendocs.alipay.com/open/54/104509)。